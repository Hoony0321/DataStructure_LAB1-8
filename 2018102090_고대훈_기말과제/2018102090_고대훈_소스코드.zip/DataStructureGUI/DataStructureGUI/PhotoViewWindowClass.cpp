#include "pch.h"
#include "PhotoViewWindowClass.h"

PhotoViewWindowClass::PhotoViewWindowClass(Application* _app,QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	app = _app;
	app->GetStorageList(storageList); //Storage ���� ������

	//�� Widget�� �´� SLOT �Լ� ����
	connect(ui.backBtn, SIGNAL(clicked(bool)), this, SLOT(BackBtnClicked()));
	connect(ui.listWidget, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(ShowTmpViewWindow1()));
	connect(ui.listWidget_2, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(ShowTmpViewWindow2()));
	connect(ui.listWidget_3, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(ShowTmpViewWindow3()));
	connect(ui.listWidget_4, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(ShowTmpViewWindow4()));
	connect(ui.listWidget_5, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(ShowTmpViewWindow5()));
	connect(ui.listWidget_6, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(ShowTmpViewWindow6()));
	connect(ui.pushButton, SIGNAL(clicked(bool)), this, SLOT(RecognitionPhoto()));

	//Table Widget�� �´� ������ ����
	SetView();
}

PhotoViewWindowClass::~PhotoViewWindowClass()
{
}

//���� ȭ������ ���ư�
void PhotoViewWindowClass::BackBtnClicked() {
	emit CloseWindow();
}

//Photo�� Storage - Container ���� �����ֱ� ����
//Table widget�� �� �´� ���� ����
void PhotoViewWindowClass::SetView() {

	//�� label, list�� ��Ȱ��ȭ�ϱ�
	ui.label_1->hide();
	ui.label_2->hide();
	ui.label_3->hide();
	ui.label_4->hide();
	ui.label_5->hide();
	ui.label_6->hide();

	ui.listWidget->hide();
	ui.listWidget_2->hide();
	ui.listWidget_3->hide();
	ui.listWidget_4->hide();
	ui.listWidget_5->hide();
	ui.listWidget_6->hide();

	//===������ ������ ���� �´� widget Ȱ��ȭ ����===//
	StorageType tmpStorage;
	ContainerType tmpContainer;
	QString qStr;


	while (storageList.GetNextItem(tmpStorage) != -1) { //Storgage ���� �ϳ��� ������
		if (tmpStorage.GetId() == 1) { //Storage 1�϶�
			ui.label_1->show();
			ui.listWidget->show();

			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				//Container Photo List View ����
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget->addItem(qStr);
			}

		}
		else if (tmpStorage.GetId() == 2) { //Storage 2�϶�
			ui.label_2->show();
			ui.listWidget_2->show();

			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				//Container Photo List View ����
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_2->addItem(qStr);
			}
		}
		else if (tmpStorage.GetId() == 3) { //Storage 3�϶�
			ui.label_3->show();
			ui.listWidget_3->show();

			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				//Container Photo List View ����
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_3->addItem(qStr);
			}
		}
		else if (tmpStorage.GetId() == 4) { //Storage 4�϶�
			ui.label_4->show();
			ui.listWidget_4->show();

			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				//Container Photo List View ����
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_4->addItem(qStr);
			}
		}
		else if (tmpStorage.GetId() == 5) { //Storage 5�϶�
			ui.label_5->show();
			ui.listWidget_5->show();

			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				//Container Photo List View ����
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_5->addItem(qStr);
			}
		}
		else if (tmpStorage.GetId() == 6) { //Storage 6�϶�
			ui.label_6->show();
			ui.listWidget_6->show();

			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				//Container Photo List View ����
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_6->addItem(qStr);
			}
		}
	}

}

//Storage ID 1�϶� ����Ǵ� �Լ�
void PhotoViewWindowClass::ShowTmpViewWindow1() { 
	StorageType tmpStorage;
	tmpStorage.SetId(1);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;

	//���õ� Container ���� ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}

	//���õ� Container photoList View
	photoListView = new PhotoListViewClass(app,tmpContainer);
	photoListView->show();

}

//Storage ID 2�϶� ����Ǵ� �Լ�
void PhotoViewWindowClass::ShowTmpViewWindow2() {
	StorageType tmpStorage;
	tmpStorage.SetId(2);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;

	//���õ� Container ���� ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_2->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}

	//���õ� Container photoList View
	photoListView = new PhotoListViewClass(app,tmpContainer);
	photoListView->show();

}

//Storage ID 3�϶� ����Ǵ� �Լ�
void PhotoViewWindowClass::ShowTmpViewWindow3() {
	StorageType tmpStorage;
	tmpStorage.SetId(3);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;

	//���õ� Container ���� ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_3->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}

	//���õ� Container photoList View
	photoListView = new PhotoListViewClass(app, tmpContainer);
	photoListView->show();

}

//Storage ID 4�϶� ����Ǵ� �Լ�
void PhotoViewWindowClass::ShowTmpViewWindow4() {
	StorageType tmpStorage;
	tmpStorage.SetId(4);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;

	//���õ� Container ���� ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_4->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}

	//���õ� Container photoList View
	photoListView = new PhotoListViewClass(app, tmpContainer);
	photoListView->show();
}

//Storage ID 5�϶� ����Ǵ� �Լ�
void PhotoViewWindowClass::ShowTmpViewWindow5() {
	StorageType tmpStorage;
	tmpStorage.SetId(5);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;

	//���õ� Container ���� ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_5->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}

	//���õ� Container photoList View
	photoListView = new PhotoListViewClass(app, tmpContainer);
	photoListView->show();
}

//Storage ID 6�϶� ����Ǵ� �Լ�
void PhotoViewWindowClass::ShowTmpViewWindow6() {
	StorageType tmpStorage;
	tmpStorage.SetId(6);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;

	//���õ� Container ���� ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_6->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}

	//���õ� Container photoList View
	photoListView = new PhotoListViewClass(app, tmpContainer);
	photoListView->show();
}

//���� �ν� ��ư SLOT - �Էµ� ���ڸ� ���� PHOTO LIST ���
void PhotoViewWindowClass::RecognitionPhoto() {
	QString qStr = ui.lineEdit->text(); //�Էµ� ���ڿ��� ������
	photoRecognitionView = new PhotoRecognitionView(app, qStr);
	photoRecognitionView->show(); //PhotoRecognition result Display
}
