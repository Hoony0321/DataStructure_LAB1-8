#include "pch.h"
#include "ModifyWindowClass.h"

ModifyWindowClass::ModifyWindowClass(Application* _app,QWidget *parent)
	: QWidget(parent)
{
	
	ui.setupUi(this);

	//Table Widget�� ���� MasterList ���� ������
	DisplayMasterList();
	app = _app;

	//widget�� slot �Լ� ����
	connect(ui.backBtn, SIGNAL(clicked(bool)), this, SLOT(BackBtnClicked()));
	connect(ui.tableWidget, SIGNAL(cellChanged(int,int)), this, SLOT(ModifyItem()));

	
	
}

ModifyWindowClass::~ModifyWindowClass()
{
}

//MasterList Display
void ModifyWindowClass::DisplayMasterList() {
	ItemType tItem;
	int index;
	QString qStr;

	
	ui.tableWidget->setRowCount(0); //���� TableWidget ������ Reset��
	app->MasterList.ResetList();

	//MasterList Display
	while (app->MasterList.GetNextItem(tItem) != -1) {
		ui.tableWidget->insertRow(ui.tableWidget->rowCount());
		index = ui.tableWidget->rowCount() - 1;

		//Item ������ �� �´� Table Header�� ������.
		ui.tableWidget->setItem(index, ID, new QTableWidgetItem(QString::number(tItem.GetId())));
		ui.tableWidget->setItem(index, NAME, new QTableWidgetItem(qStr.fromUtf8(tItem.GetName().c_str())));
		ui.tableWidget->setItem(index, KIND, new QTableWidgetItem(qStr.fromUtf8(tItem.GetKind().c_str())));
		ui.tableWidget->setItem(index, DATE, new QTableWidgetItem(QString::number(tItem.GetDate())));
		ui.tableWidget->setItem(index, AMOUNT, new QTableWidgetItem(QString::number(tItem.GetAmount())));
		ui.tableWidget->setItem(index, STORAGE_ID, new QTableWidgetItem(QString::number(tItem.GetStorageId())));
		ui.tableWidget->setItem(index, CONTAINER_ID, new QTableWidgetItem(QString::number(tItem.GetContainerID())));
		ui.tableWidget->setItem(index, PHOTO, new QTableWidgetItem(qStr.fromUtf8(tItem.GetPhoto().c_str())));
		ui.tableWidget->setItem(index, SEARCH_NUMBER, new QTableWidgetItem(QString::number(tItem.GetNumOfSearch())));
	}
}

//�Էµ� ������ ���� Item ���� ���� - �����ؾ���
void ModifyWindowClass::ModifyItem() {
	
	//�˸�â ����
	AlertWindowClass* alertWindow;
	alertWindow = new AlertWindowClass();

	
	ItemType tItem;

	//Item ���� Setting
	int index = ui.tableWidget->currentRow();
	Item = ui.tableWidget->item(index, 0);
	tItem.SetId(stoi(Item->text().toUtf8().constData()));
	Item = ui.tableWidget->item(index, 1);
	tItem.SetName(Item->text().toUtf8().constData());
	Item = ui.tableWidget->item(index, 2);
	tItem.SetKind(Item->text().toUtf8().constData());
	Item = ui.tableWidget->item(index, 3);
	tItem.SetDate(Item->text().toInt());
	Item = ui.tableWidget->item(index, 4);
	tItem.SetAmount(Item->text().toInt());
	Item = ui.tableWidget->item(index, 5);
	tItem.SetStorageId(Item->text().toInt());
	Item = ui.tableWidget->item(index, 6);
	tItem.SetContainerID(Item->text().toInt());
	Item = ui.tableWidget->item(index, 7);
	tItem.SetPhoto(Item->text().toUtf8().constData());
	Item = ui.tableWidget->item(index, 8);
	tItem.SetNumOfSearch(Item->text().toInt());


	//Replace ����
	if (app->ReplaceItem(tItem) == 1) {
		QString qStr = QString::fromLocal8Bit("���� ����!!!");
		alertWindow->SetText(qStr);
		alertWindow->show();

	}
	else { //Replace ����
		QString qStr = QString::fromLocal8Bit("���� ����!!!");
		alertWindow->SetText(qStr);
		alertWindow->show();
	}

	
}

//���� ȭ������ ���ư��� �Լ�
void ModifyWindowClass::BackBtnClicked() {
	emit CloseWindow();
}

