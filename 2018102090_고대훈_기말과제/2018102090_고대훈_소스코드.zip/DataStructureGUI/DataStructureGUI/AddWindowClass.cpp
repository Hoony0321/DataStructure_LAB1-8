#include "pch.h"
#include "AddWindowClass.h"


AddWindowClass::AddWindowClass(Application* _app,QWidget* parent)
	: QWidget(parent)
{
	app = _app;
	ui.setupUi(this);

	//widget�� slot �Լ� ����
	connect(ui.backBtn, SIGNAL(clicked(bool)), this, SLOT(BackBtnClicked()));
	connect(ui.pushButton, SIGNAL(clicked(bool)), this, SLOT(AddItemBtnClicked()));
	connect(ui.pushButton_2, SIGNAL(clicked(bool)), this, SLOT(Clear()));

	//Table Widget�� ���� MasterList ���� ������
	DisplayMasterList();

}

AddWindowClass::~AddWindowClass()
{
}

//���� ȭ������ ���ư��� �Լ�
void AddWindowClass::BackBtnClicked() {
	emit CloseWindow();
}

//�Էµ� ���� Clear�ϴ� �Լ�
void AddWindowClass::Clear() {
	//ID set
	ui.lineEdit->clear();
	//STORAGE ID set
	ui.lineEdit_2->clear();
	//CONTAINER ID set
	ui.lineEdit_3->clear();
	//NAME set
	ui.lineEdit_4->clear();
	//KIND set
	ui.lineEdit_5->clear();
	//DATE set
	ui.lineEdit_7->clear();
	//AMOUNT set
	ui.lineEdit_8->clear();
	//PHOTO set
	ui.lineEdit_9->clear();
}

//�Էµ� ������ ���� ������
void AddWindowClass::AddItemBtnClicked() {
	ItemType tItem;	

	//LineEdit�� �Էµ� �л� ������ �о�� MasterList�� ����
	//ID set
	tItem.SetId(stoi(ui.lineEdit->text().toUtf8().constData()));
	//STORAGE ID set
	tItem.SetStorageId(stoi(ui.lineEdit_2->text().toUtf8().constData()));
	//CONTAINER ID set
	tItem.SetContainerID(stoi(ui.lineEdit_3->text().toUtf8().constData()));
	//NAME set
	tItem.SetName(ui.lineEdit_4->text().toUtf8().constData());
	//KIND set
	tItem.SetKind(ui.lineEdit_5->text().toUtf8().constData());
	//DATE set
	tItem.SetDate(stoi(ui.lineEdit_7->text().toUtf8().constData()));
	//AMOUNT set
	tItem.SetAmount(stoi(ui.lineEdit_8->text().toUtf8().constData()));
	//PHOTO set
	tItem.SetPhoto(ui.lineEdit_9->text().toUtf8().constData());

	AlertWindowClass* alertWindow;
	alertWindow = new AlertWindowClass();
	//MasterList�� ���� �߰�
	if (app->AddItem(tItem) == 1) {
		QString qStr = QString::fromLocal8Bit("�߰� ����!!!");
		alertWindow->SetText(qStr);
		alertWindow->show();
	}
	else {
		QString qStr = QString::fromLocal8Bit("�߰� ����!!!");
		alertWindow->SetText(qStr);
		alertWindow->show();
	}

	//Update�� MasterList ���� Display
	DisplayMasterList();

	
}

//MasterList Display
void AddWindowClass::DisplayMasterList() {
	ItemType tItem;
	int index;
	QString qStr;

	
	ui.tableWidget->setRowCount(0);  //���� TableWidget ������ Reset��
	
	app->MasterList.ResetList();

	//MasterList Display
	while (app->MasterList.GetNextItem(tItem) != -1) {
		ui.tableWidget->insertRow(ui.tableWidget->rowCount());
		index = ui.tableWidget->rowCount() - 1;

		//Item ������ �� �´� Table Header�� ������.
		ui.tableWidget->setItem(index, ID, new QTableWidgetItem(QString::number(tItem.GetId())));
		ui.tableWidget->setItem(index, NAME, new QTableWidgetItem(qStr.fromUtf8(tItem.GetName().c_str())));
		ui.tableWidget->setItem(index, KIND, new QTableWidgetItem(qStr.fromUtf8(tItem.GetKind().c_str())));
		ui.tableWidget->setItem(index, DATE, new QTableWidgetItem(QString::number(tItem.GetDate())));
		ui.tableWidget->setItem(index, AMOUNT, new QTableWidgetItem(QString::number(tItem.GetAmount())));
		ui.tableWidget->setItem(index, STORAGE_ID, new QTableWidgetItem(QString::number(tItem.GetStorageId())));
		ui.tableWidget->setItem(index, CONTAINER_ID, new QTableWidgetItem(QString::number(tItem.GetContainerID())));
		ui.tableWidget->setItem(index, PHOTO, new QTableWidgetItem(qStr.fromUtf8(tItem.GetPhoto().c_str())));
		ui.tableWidget->setItem(index, SEARCH_NUMBER, new QTableWidgetItem(QString::number(tItem.GetNumOfSearch())));
	}
}


