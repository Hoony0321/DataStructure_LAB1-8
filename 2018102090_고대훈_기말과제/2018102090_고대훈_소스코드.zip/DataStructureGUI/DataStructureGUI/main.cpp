#include "pch.h"
#include "LoginGUIClass.h"
#include "MainWindowClass.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
	
	//MainWindow ����
	MainWindowClass mainWindow;
	mainWindow.show();

    return a.exec();
}
