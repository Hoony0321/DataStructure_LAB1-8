#pragma once

#include <QWidget>
#include "ui_LoginGUIClass.h"
#include "MainWindowClass.h"

class LoginGUIClass : public QWidget
{
	Q_OBJECT

public:
	LoginGUIClass(QWidget *parent = Q_NULLPTR);
	~LoginGUIClass();

private:
	Ui::LoginGUIClass ui;

	MainWindowClass* mainWindow;

private slots:
	void Login();
};
