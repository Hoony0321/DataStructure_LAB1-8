#pragma once

#include <QWidget>
#include "ui_ImageWindowClass.h"

class ImageWindowClass : public QWidget
{
	Q_OBJECT

public:
	ImageWindowClass(QString _imageLocation, QWidget *parent = Q_NULLPTR);
	~ImageWindowClass();

private:
	Ui::ImageWindowClass ui;
	QString imageLocation; //image ��ġ�� ���� ����
};
