#pragma once

#include "SortedList.h"


class ItemType;


class Base {

public:
	static SortedList<ItemType> MasterList;  //DataBase ����
	
};

