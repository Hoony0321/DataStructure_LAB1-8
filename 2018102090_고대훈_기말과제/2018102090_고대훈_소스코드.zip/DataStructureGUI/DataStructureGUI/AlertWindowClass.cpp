#include "pch.h"
#include "AlertWindowClass.h"

AlertWindowClass::AlertWindowClass(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	connect(ui.pushButton, SIGNAL(clicked(bool)), this, SLOT(CloseWindow()));
}

AlertWindowClass::~AlertWindowClass()
{
}

//label text�� �����մϴ�.
void AlertWindowClass::SetText(QString str) {
	ui.label->setText(str);
}

//label text size ����
void AlertWindowClass::SetTextSize(int size) {
	ui.label->setFont(QFont("Agency FB", 10));
}

//â�� �ݴ� SLOT �Լ�
void AlertWindowClass::CloseWindow() {
	ui.label->setText("");
	this->close();
}


