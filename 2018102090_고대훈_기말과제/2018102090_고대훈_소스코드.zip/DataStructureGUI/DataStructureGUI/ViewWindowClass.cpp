#include "pch.h"
#include "ViewWindowClass.h"

ViewWindowClass::ViewWindowClass(Application* _app, QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	app = _app;
	app->GetStorageList(storageList);

	//widget�� slot�Լ� ����
	connect(ui.backBtn, SIGNAL(clicked(bool)), this, SLOT(BackBtnClicked()));
	connect(ui.listWidget, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(ShowTmpViewWindow1()));
	connect(ui.listWidget_2, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(ShowTmpViewWindow2()));
	connect(ui.listWidget_3, SIGNAL(itemDoubleClicked(QListWidgetItem *)), this, SLOT(ShowTmpViewWindow3()));
	connect(ui.listWidget_4, SIGNAL(itemDoubleClicked(QListWidgetItem *)), this, SLOT(ShowTmpViewWindow4()));
	connect(ui.listWidget_5, SIGNAL(itemDoubleClicked(QListWidgetItem *)), this, SLOT(ShowTmpViewWindow5()));
	connect(ui.listWidget_6, SIGNAL(itemDoubleClicked(QListWidgetItem *)), this, SLOT(ShowTmpViewWindow6()));

	//Storage�� ��Ÿ���� widget�� �����Ǳ� ���� ����
	ui.label_1->hide();
	ui.label_2->hide();
	ui.label_3->hide();
	ui.label_4->hide();
	ui.label_5->hide();
	ui.label_6->hide();
	ui.listWidget->hide();
	ui.listWidget_2->hide();
	ui.listWidget_3->hide();
	ui.listWidget_4->hide();
	ui.listWidget_5->hide();
	ui.listWidget_6->hide();

	//StorageList ������ ���� �� Widget Ȱ��ȭ �� ���� ����
	SetView();

	
	
}

ViewWindowClass::~ViewWindowClass()
{
}

//���� ȭ������ ���ư��� �Լ�
void ViewWindowClass::BackBtnClicked() {
	emit CloseWindow();
}

//StorageList�� �ִ� ������ ���� �� �´� widget Ȱ��ȭ �� ���� �Է�
void ViewWindowClass::SetView() {
	
	
	StorageType tmpStorage;
	ContainerType tmpContainer;
	QString qStr;

	
	while (storageList.GetNextItem(tmpStorage) != -1) {
		
		if (tmpStorage.GetId() == 1) { //Storage ID  = 1
			//widget Ȱ��ȭ
			ui.label_1->show();
			ui.listWidget->show();

			//Ȱ��ȭ�� widget�� ���� �Է�
			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget->addItem(qStr);
			}

		}
		else if (tmpStorage.GetId() == 2) { //Storage ID  = 2
			//widget Ȱ��ȭ
			ui.label_2->show();
			ui.listWidget_2->show();

			//Ȱ��ȭ�� widget�� ���� �Է�
			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_2->addItem(qStr);
			}
		}
		else if (tmpStorage.GetId() == 3) { //Storage ID  = 3
			//widget Ȱ��ȭ
			ui.label_3->show();
			ui.listWidget_3->show();

			//Ȱ��ȭ�� widget�� ���� �Է�
			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_3->addItem(qStr);
			}
		}
		else if (tmpStorage.GetId() == 4) { //Storage ID  = 4
			//widget Ȱ��ȭ
			ui.label_4->show();
			ui.listWidget_4->show();

			//Ȱ��ȭ�� widget�� ���� �Է�
			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_4->addItem(qStr);
			}
		}
		else if (tmpStorage.GetId() == 5) { //Storage ID  = 5
			//widget Ȱ��ȭ
			ui.label_5->show();
			ui.listWidget_5->show();

			//Ȱ��ȭ�� widget�� ���� �Է�
			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_5->addItem(qStr);
			}
		}
		else if (tmpStorage.GetId() == 6) { //Storage ID  = 6
			//widget Ȱ��ȭ
			ui.label_6->show();
			ui.listWidget_6->show();

			//Ȱ��ȭ�� widget�� ���� �Է�
			tmpStorage.ResetList();
			while (tmpStorage.GetNextContainer(tmpContainer) != 0) {
				qStr = QString::fromUtf8(("Container" + to_string(tmpContainer.GetId())).c_str());
				ui.listWidget_6->addItem(qStr);
			}
		}
	}
	
}

//=================== �� Storage ID�� �´� Widget Show ===================//
void ViewWindowClass::ShowTmpViewWindow1() {
	StorageType tmpStorage;
	tmpStorage.SetId(1);
	storageList.GetByBinarySearch(tmpStorage); //Storage ID 1�� storage ������

	ContainerType tmpContainer;

	tmpStorage.ResetList();

	//double click �� Container ��������
	for (int i = 0; i < ui.listWidget->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}

	//container ���� �����ִ� window
	TempViewWindow = new TempViewClass(app, tmpContainer);
	TempViewWindow->show();
}

void ViewWindowClass::ShowTmpViewWindow2() {
	StorageType tmpStorage;
	tmpStorage.SetId(2);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;
	//double click �� Container ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_2->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}
	//container ���� �����ִ� window
	TempViewWindow = new TempViewClass(app, tmpContainer);
	TempViewWindow->show();
}

void ViewWindowClass::ShowTmpViewWindow3() {
	StorageType tmpStorage;
	tmpStorage.SetId(3);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;
	//double click �� Container ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_3->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}
	//container ���� �����ִ� window
	TempViewWindow = new TempViewClass(app, tmpContainer);
	TempViewWindow->show();
}

void ViewWindowClass::ShowTmpViewWindow4() {
	StorageType tmpStorage;
	tmpStorage.SetId(4);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;
	//double click �� Container ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_4->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}
	//container ���� �����ִ� window
	TempViewWindow = new TempViewClass(app, tmpContainer);
	TempViewWindow->show();
}

void ViewWindowClass::ShowTmpViewWindow5() {
	StorageType tmpStorage;
	tmpStorage.SetId(5);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;
	//double click �� Container ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_5->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}
	//container ���� �����ִ� window
	TempViewWindow = new TempViewClass(app, tmpContainer);
	TempViewWindow->show();
}

void ViewWindowClass::ShowTmpViewWindow6() {
	StorageType tmpStorage;
	tmpStorage.SetId(6);
	storageList.GetByBinarySearch(tmpStorage);

	ContainerType tmpContainer;
	//double click �� Container ��������
	tmpStorage.ResetList();
	for (int i = 0; i < ui.listWidget_6->currentRow() + 1; i++) {
		tmpStorage.GetNextContainer(tmpContainer);
	}
	//container ���� �����ִ� window
	TempViewWindow = new TempViewClass(app, tmpContainer);
	TempViewWindow->show();
}




