#include "pch.h"

int main() {

	Application App;     //program application.
	App.Run();			//application run.

	return 0;
}