#include "pch.h"
#include "SimpleItemType.h"