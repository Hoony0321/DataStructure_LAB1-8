#include "Application.h"

int main() {

	Application app;
	app.Run();

	return 0;

}