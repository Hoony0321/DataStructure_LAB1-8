/**
*	Lab 1: Implementtaion of a list class using array. 
*/

#include "Application.h"

/**
*	program main function for data structures course.
*/
int main()
{
	Application app;	// Application class object that controls the application
	app.Run();			// initiate the application

	return 0;
}