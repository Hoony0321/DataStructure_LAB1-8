﻿/**
*	@mainpage	BinarySearchTree
*				This is a simple example of Lab07 on data structures course.<br>

*	@date	
*	@author	
*/

#include "Application.h"

int main()
{
	Application app;
	app.Run();

	return 0;
}