#pragma once

#include "DoublySortedLinkedList.h"



template<class T>
class BinarySearchTree;



class Base {

public:
	static BinarySearchTree<ItemType> MasterList;

};

