#pragma once


template<typename T>
class CHeapBase;

class ItemType;

class Base {

public:
	static CHeapBase<ItemType>* MasterList;
	
	
};

