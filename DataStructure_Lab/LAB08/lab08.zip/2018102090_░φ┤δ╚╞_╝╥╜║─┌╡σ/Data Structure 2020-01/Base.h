#pragma once

#include "DoublySortedLinkedList.h"

template<typename T>
class CMinHeap;

class Base {

public:
	static CMinHeap<ItemType> MasterList;
	
	
};

