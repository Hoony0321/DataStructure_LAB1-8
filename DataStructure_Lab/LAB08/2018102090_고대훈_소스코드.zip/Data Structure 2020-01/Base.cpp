#include "pch.h"
#include "Base.h"


//=====Static ������ ����=====//
DoublySortedLinkedList<ItemType> Base::MasterList;
SortedList<ContainerType> Base::ContainerList;
TempType Base::TempList;
SortedList<StorageType> Base::StorageList;
Stack<SimpleItemType> Base::SearchList;