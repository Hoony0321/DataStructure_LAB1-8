#include "pch.h"
#include "Base.h"

//SortedList<ItemType> TempMastesr;
//SortedList<ItemType> Base::MasterList;

DoublySortedLinkedList<ItemType> Base::MasterList;

//SortedList<ContainerType> TempContainer;
SortedList<ContainerType> Base::ContainerList;

//TempType TempTemp;
TempType Base::TempList;

//SortedList<StorageType> TempStorage;
SortedList<StorageType> Base::StorageList;